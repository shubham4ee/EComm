﻿namespace UserServer.BLL.DTOs
{
    public class CreateProjectDto
    {
        public string ProjectName { get; set; }
        public string Description { get; set; }
    }
}
