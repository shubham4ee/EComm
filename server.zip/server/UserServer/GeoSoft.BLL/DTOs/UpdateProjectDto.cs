﻿namespace UserServer.BLL.DTOs
{
    public class UpdateProjectDto
    {
        public required string ProjectName { get; set; }
        public required string Description { get; set; }
    }
}
